package javaapplication101;
import java.util.Scanner;
import java.text.DecimalFormat;


public class gwapo {
     public static void main(String[] args) {
         
         netgenpay gnp = new netgenpay();
         gnp.netGen();
         
         
     }
    
    
}
